import java.util.*;

class fact{
    int num ;
    fact(int num)
    {
        System.out.println("factor of " + num + "are : ");
        for (int i=1;i<=num; i++)
        {
            if(num % i  == 0 ){
                System.out.print(i+" ");
            }
        }
        System.out.println();
    }
}

class test {
    public static void main (String [] args)
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a number:");
        int num = sc.nextInt();

        fact f = new fact(num);
    }
}