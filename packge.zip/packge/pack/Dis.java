package pack;
import pack.*;

public class Dis {
    U_marks um = new U_marks();
    public void display()
    {
        int k=1, t=0, per=0;
        System.out.println("\n------------------------ Display Data ---------------------\n");
        System.out.println("NO\t\t" + "Subject_name\t\t\t" + "Marks");
        System.out.println("---------------------------------------------------------------");
        for(int i=0; i<um.marks.length; i++)
        {
            System.out.println(k + " \t\t\t" + um.u.s_nm[i] + "\t\t\t" + um.marks[i]);
            t= t+um.marks[i];
            k++;
        }
        per = t/um.marks.length;
        System.out.println("\n------------------------ Total Marks ---------------------\n");
        System.out.println("Total : " + t);
        System.out.println("\n------------------------ Percentage ---------------------\n");
        System.out.println("Percentage : " + per + "%");
    }
}
