import pack.*;

class Result
{
    public static void main (String[] args)
    {
        Dis d = new Dis();
        d.display();
    } 
}